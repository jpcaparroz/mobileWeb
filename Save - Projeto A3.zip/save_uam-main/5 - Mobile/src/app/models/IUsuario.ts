/* eslint-disable @typescript-eslint/naming-convention */
export interface IUsuario{
    nome?:string;
    email?:string;
}
export interface IFilme{
    nome: string;
    anoLancamento: string;
    duracao: string;
    classificacao: number;
    cartaz: string;
    generos: string[];
    pagina?: string;
}